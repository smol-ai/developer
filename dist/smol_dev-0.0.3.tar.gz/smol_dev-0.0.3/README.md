# 🐣 smol developer

<a href="https://app.e2b.dev/agent/smol-developer" target="_blank" rel="noopener noreferrer">
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://app.e2b.dev/api/badge_light">
  <img alt="Deploy agent on e2b button" src="https://app.e2b.dev/api/badge"/>
</picture>
</a>

```bash
python main.py --prompt prompt.md # defaults to gpt4
python main.py --prompt prompt.md --model=gpt-3.5-turbo-0613
# python main.py --prompt prompt.md --model=gpt-4-0613 # defaults to gpt-4
```

from smol_dev.prompts import plan, specify_file_paths, generate_code
